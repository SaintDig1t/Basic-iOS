//
//  Resevation Form.swift
//  Reservation form
//
//  Created by Henry Rivera Osso on 6/27/23.
//

import SwiftUI

struct Reservation_Form: View {
    @State var customerName: String = ""
    var body: some View {
        Form {
            TextField("Type Your name", text: $customerName, onEditingChanged: { status in print(status)})
                .onSubmit ({
                    print("Submitted")
                })
                .onChange(of: customerName, perform: { newValue in print(newValue)})
        }
        .padding()
    }
}

struct Reservation_Form_Previews: PreviewProvider {
    static var previews: some View{
        Reservation_Form()
    }
}
