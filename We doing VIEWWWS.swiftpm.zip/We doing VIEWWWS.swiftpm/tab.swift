//
//  tab.swift
//  We doing VIEWWWS
//
//  Created by Henry Rivera Osso on 6/28/23.
//

import SwiftUI

struct tab: View {
    var body: some View {
        VStack{
            TabView{
                Text("This is the share view").tabItem({
                    Label("Share", systemImage: "square.and.arrow.up")
                })
                Text("This is the trash View").tabItem({
                    Label("", systemImage: "trash")
                })
            }
            
        }
    }
}

struct tab_Previews: PreviewProvider {
    static var previews: some View {
        tab()
    }
}
