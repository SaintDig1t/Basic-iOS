//
//  Nav.swift
//  We doing VIEWWWS
//
//  Created by Henry Rivera Osso on 6/28/23.
//

import SwiftUI

struct SecondView: View {
    var body: some View{
        Text("Do something")
    }
}

struct Nav: View {
    var body : some View{
        NavigationView{
            VStack{
                Text("Exercise 1")
                NavigationLink(destination: SecondView()) {
                    Text("Do Something")
                }
            }
            .navigationTitle("Little Lemon")
        }
    }
}



struct Nav_Previews: PreviewProvider {
    static var previews: some View {
        Nav()
    }
}
