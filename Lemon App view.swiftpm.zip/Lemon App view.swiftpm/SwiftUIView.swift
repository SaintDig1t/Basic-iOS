//
//  SwiftUIView.swift
//  Lemon App view
//
//  Created by Henry Rivera Osso on 6/27/23.
//

import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        NavigationView(content: {
            VStack(content: {
                ZStack(content: {
                    HStack(spacing: 8){
                        Text("Demo").scaledToFit().frame( width: 100, height: 100, alignment: .center)
                        VStack(spacing: 10) {
                            Text("Little Lemon").font(.title)
                            Text("Tomato Tortellini, Bottarga and Carbonara").font(.title3).multilineTextAlignment(.center)
                        } //: - VStack()
                        .padding()
                    }//:- HStack
                    .padding()
                })
            })
        })
    }
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View{
        SwiftUIView()
    }
}
